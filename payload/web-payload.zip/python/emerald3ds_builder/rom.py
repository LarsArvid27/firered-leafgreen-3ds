"""Recognise the player's ROM.

Clean Pokémon FireRed (BPRE) and LeafGreen (BPGE) USA v1.0 dumps are recognised
(16 MiB, by SHA-1); version 1.1 is named as such and refused. Building still requires a recipe and
executable made for the same ROM. A trimmed dump (trailing 0xFF removed) is padded back before it is checked; a .zip holding a single .gba is
opened directly. The ROM is only ever read into memory: it is never copied,
written or sent anywhere.
"""

from __future__ import annotations

import hashlib
import io
import zipfile
from dataclasses import dataclass
from pathlib import Path

from .errors import BuilderError

# FireRed 3DS / LeafGreen 3DS: the USA v1.0 cartridges (no-intro; pret/pokefirered).
FIRERED_SHA1 = "41cb23d8dccc8ebd7c649cd8fbb58eeace6e2fdc"
LEAFGREEN_SHA1 = "574fa542ffebb14be69902d1d36f1ec0a4afd71e"
SUPPORTED_SHA1 = FIRERED_SHA1
# Emerald 3DS's, kept for the shared tests and tools.
SPANISH_SHA1 = "fe1558a3dcb0360ab558969e09b690888b846dd9"
FRENCH_SHA1 = "ca666651374d89ca439007bed54d839eb7bd14d0"
ITALIAN_SHA1 = "1692db322400c3141c5de2db38469913ceb1f4d4"
GERMAN_SHA1 = "61c2eb2b380b1a75f0c94b767a2d4c26cd7ce4e3"
JAPANESE_SHA1 = "d7cf8f156ba9c455d164e1ea780a6bf1945465c2"
ROM_PROFILES = {"BPRE": FIRERED_SHA1, "BPGE": LEAFGREEN_SHA1}
# Each game's folder on the SD card and its files' names.
GAMES = {
    FIRERED_SHA1: {"code": "BPRE", "name": "Pokemon FireRed (USA) v1.0", "title": "FireRed 3DS",
                   "dir": "3ds/firered3ds", "app": "firered3ds", "exe": "FireRed3DS"},
    LEAFGREEN_SHA1: {"code": "BPGE", "name": "Pokemon LeafGreen (USA) v1.0", "title": "LeafGreen 3DS",
                     "dir": "3ds/leafgreen3ds", "app": "leafgreen3ds", "exe": "LeafGreen3DS"},
}
ROM_SIZE = 16 * 1024 * 1024
KNOWN_CODES = {
    "BPEE": "Pokemon Emerald (USA, Europe)",
    "BPEJ": "Pokemon Emerald (Japan)",
    "BPES": "Pokemon Emerald (Spain)",
    "BPED": "Pokemon Emerald (Germany)",
    "BPEF": "Pokemon Emerald (France)",
    "BPEI": "Pokemon Emerald (Italy)",
    "AXVE": "Pokemon Ruby",
    "AXVJ": "Pokemon Ruby (Japan)",
    "AXVS": "Pokemon Ruby (Spain)",
    "AXVD": "Pokemon Ruby (Germany)",
    "AXVF": "Pokemon Ruby (France)",
    "AXVI": "Pokemon Ruby (Italy)",
    "AXPE": "Pokemon Sapphire",
    "AXPJ": "Pokemon Sapphire (Japan)",
    "AXPS": "Pokemon Sapphire (Spain)",
    "AXPD": "Pokemon Sapphire (Germany)",
    "AXPF": "Pokemon Sapphire (France)",
    "AXPI": "Pokemon Sapphire (Italy)",
    "BPRE": "Pokemon FireRed (USA)",
    "BPRJ": "Pokemon FireRed (Japan)",
    "BPRS": "Pokemon FireRed (Spain)",
    "BPRD": "Pokemon FireRed (Germany)",
    "BPRF": "Pokemon FireRed (France)",
    "BPRI": "Pokemon FireRed (Italy)",
    "BPGE": "Pokemon LeafGreen (USA)",
    "BPGJ": "Pokemon LeafGreen (Japan)",
    "BPGS": "Pokemon LeafGreen (Spain)",
    "BPGD": "Pokemon LeafGreen (Germany)",
    "BPGF": "Pokemon LeafGreen (France)",
    "BPGI": "Pokemon LeafGreen (Italy)",
}


@dataclass
class Rom:
    data: bytes
    sha1: str
    title: str
    code: str
    source: Path


def _unzip(data: bytes) -> bytes:
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = [n for n in zf.namelist() if n.lower().endswith((".gba", ".agb", ".bin"))]
        if len(names) != 1:
            raise BuilderError("The ZIP file must contain exactly one .gba file.", code="rom_zip_contents")
        return zf.read(names[0])


def header(data: bytes) -> tuple[str, str]:
    if len(data) < 0xC0:
        return "", ""
    title = data[0xA0:0xAC].split(b"\0")[0].decode("ascii", "replace")
    code = data[0xAC:0xB0].decode("ascii", "replace")
    return title, code


def check_rom_bytes(data: bytes, source: Path, supported: tuple[str, ...] | None = None) -> Rom:
    """Recognise ROM bytes already in memory (the web builder has no file)."""
    if source.suffix.lower() == ".zip":
        try:
            data = _unzip(data)
        except zipfile.BadZipFile as exc:
            raise BuilderError("The ROM file could not be read.", str(exc), code="rom_unreadable") from exc
    if len(data) > ROM_SIZE:
        raise BuilderError("This file is larger than a GBA cartridge; it is not the supported ROM.",
                           code="rom_too_large")
    if len(data) < ROM_SIZE:
        # A trimmed dump: the cartridge's trailing 0xFF fill was cut off.
        data = data + b"\xff" * (ROM_SIZE - len(data))
    title, code = header(data)
    sha1 = hashlib.sha1(data).hexdigest()
    if supported is None:
        supported = tuple(ROM_PROFILES.values())
    if sha1 not in supported:
        codes = [c for c, s in ROM_PROFILES.items() if s in supported] or ["BPRE"]
        names = " or ".join(KNOWN_CODES[c] for c in codes)
        what = KNOWN_CODES.get(code)
        if what and code not in codes:
            raise BuilderError("This ROM is %s. Only %s is supported." % (what, names),
                               code="rom_wrong_game")
        if code in codes and data[0xBC] != 0:
            raise BuilderError(
                "This is %s version 1.%d. Only version 1.0 is supported." % (what, data[0xBC]),
                "Use a dump of a version 1.0 cartridge (SHA-1 %s)." % ROM_PROFILES[code],
                code="rom_wrong_revision")
        if code in codes:
            raise BuilderError(
                "This is a %s ROM, but not an unmodified one." % what,
                "Patched, hacked or bad dumps are not supported. Use a clean dump of your cartridge "
                "(SHA-1 %s)." % ROM_PROFILES[code], code="rom_modified")
        raise BuilderError("This file is not the supported ROM.",
                           "Expected %s, SHA-1 %s." % (names, " or ".join(ROM_PROFILES[c] for c in codes)),
                           code="rom_unsupported")
    return Rom(data=data, sha1=sha1, title=title, code=code, source=source)


def load_rom(path: Path, supported: tuple[str, ...] | None = None) -> Rom:
    path = Path(path)
    if not path.is_file():
        raise BuilderError("The ROM file was not found:\n%s" % path.name, code="rom_not_found")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise BuilderError("The ROM file could not be read.", str(exc), code="rom_unreadable") from exc
    return check_rom_bytes(data, path, supported)
